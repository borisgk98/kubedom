SERVER_URL = 'kubedom.borisgk.space'
WS_PATH = '/api/kubedom/ws/provider'
CONFIG_PATH = '/etc/kubedom/config.ini'
# CONFIG_PATH = '/home/boris/.kubedom/node.ini'