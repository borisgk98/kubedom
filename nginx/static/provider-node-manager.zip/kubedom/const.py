SERVER_URL = 'kubedom.borisgk.space'
SERVER_PORT = 8081
WS_PATH = '/api/kubedom/ws/provider'
CONFIG_PATH = '/etc/kubedom/config.ini'
OVA_FILE_LOCATION = "/tmp/customer-node.ova"