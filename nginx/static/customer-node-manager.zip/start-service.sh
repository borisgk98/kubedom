/usr/bin/python3 /opt/kubedom/customer-node-manager/main.py &
PID=$!
echo $PID > /run/customer-node-manager.pid