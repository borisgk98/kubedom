SERVER_URL = 'kubedom.borisgk.space'
WS_PATH = '/api/kubedom/ws/customer'