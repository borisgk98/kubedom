SERVER_URL = 'kubedom.borisgk.space'
SERVER_PORT = 8081
WS_PATH = '/api/kubedom/ws/customer'
START_WORKER_SCRIPT_PATH = '/opt/kubedom/customer-node-manager/start-worker-node.sh'
PROVIDER_CONFIG_PATH = "/home/vm-provider/config.json"
LOCAL_CONFIG_PATH = "/etc/kubedom/config.json"
LOG_PATH = '/var/log/kubedom/customer.log'