class ClientNode:
    __machine__ = None
    __